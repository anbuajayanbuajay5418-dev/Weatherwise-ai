const router = require('express').Router();
const protect = require('../middleware/auth');
const { current, recommendation } = require('../controllers/weatherController');

router.use(protect);
router.get('/current', current);
router.get('/recommendation', recommendation);

module.exports = router;
