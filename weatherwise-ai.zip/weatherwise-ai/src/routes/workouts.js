const router = require('express').Router();
const protect = require('../middleware/auth');
const c = require('../controllers/workoutController');

router.use(protect);
router.route('/').post(c.createWorkout).get(c.getWorkouts);
router.route('/:id').get(c.getWorkout).put(c.updateWorkout).delete(c.deleteWorkout);

module.exports = router;
