const { GoogleGenerativeAI } = require('@google/generative-ai');

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');

exports.getRecommendation = async ({ weather, recentWorkouts, workoutType }) => {
  const model = genAI.getGenerativeModel({
    model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
    generationConfig: { responseMimeType: 'application/json', temperature: 0.4 },
  });

  const history = recentWorkouts.length
    ? recentWorkouts
        .map((w) => `- ${new Date(w.date).toDateString()}: ${w.type}, ${w.durationMinutes} min`)
        .join('\n')
    : 'No workout history yet.';

  const prompt = `You are WeatherWise, a fitness and weather assistant.
Analyze the real-time weather and the user's recent workouts, then give a safe, practical recommendation.

WEATHER:
${JSON.stringify(weather)}

PREFERRED WORKOUT TYPE: ${workoutType || 'not specified'}

RECENT WORKOUTS:
${history}

Respond ONLY with JSON in this shape:
{
  "suitability": "great" | "good" | "caution" | "avoid",
  "summary": "one or two sentences",
  "bestTimeToExercise": "string",
  "recommendedActivity": "string",
  "clothing": ["string"],
  "hydrationTip": "string",
  "safetyWarnings": ["string"]
}`;

  const result = await model.generateContent(prompt);
  try {
    return JSON.parse(result.response.text());
  } catch {
    const err = new Error('AI returned an invalid response');
    err.status = 502;
    throw err;
  }
};
