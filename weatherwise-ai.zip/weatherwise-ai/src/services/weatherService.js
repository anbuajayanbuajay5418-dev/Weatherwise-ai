// Uses OpenWeatherMap "current weather" API (Node 18+ global fetch)
exports.getCurrentWeather = async (city) => {
  const url =
    `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}` +
    `&units=metric&appid=${process.env.OPENWEATHER_API_KEY}`;

  const res = await fetch(url);
  if (res.status === 404) {
    const err = new Error(`City not found: ${city}`);
    err.status = 404;
    throw err;
  }
  if (!res.ok) {
    const err = new Error('Weather provider error');
    err.status = 502;
    throw err;
  }
  const d = await res.json();
  return {
    city: d.name,
    country: d.sys?.country,
    condition: d.weather?.[0]?.main,
    description: d.weather?.[0]?.description,
    temperatureC: d.main.temp,
    feelsLikeC: d.main.feels_like,
    humidity: d.main.humidity,
    windSpeedMs: d.wind?.speed,
    cloudiness: d.clouds?.all,
    visibilityM: d.visibility,
    sunrise: d.sys?.sunrise ? new Date(d.sys.sunrise * 1000).toISOString() : null,
    sunset: d.sys?.sunset ? new Date(d.sys.sunset * 1000).toISOString() : null,
  };
};
