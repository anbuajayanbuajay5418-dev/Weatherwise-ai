const mongoose = require('mongoose');

const workoutSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    type: {
      type: String,
      required: true,
      enum: ['running', 'cycling', 'walking', 'swimming', 'gym', 'yoga', 'hiking', 'other'],
    },
    durationMinutes: { type: Number, required: true, min: 1 },
    distanceKm: { type: Number, min: 0 },
    caloriesBurned: { type: Number, min: 0 },
    location: { type: String, trim: true },
    notes: { type: String, trim: true, maxlength: 500 },
    date: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Workout', workoutSchema);
