const Workout = require('../models/Workout');
const { getCurrentWeather } = require('../services/weatherService');
const { getRecommendation } = require('../services/aiService');

const resolveCity = (req) => req.query.city || req.user?.city;

exports.current = async (req, res, next) => {
  try {
    const city = resolveCity(req);
    if (!city) return res.status(400).json({ message: 'Provide ?city= or set a default city' });
    res.json(await getCurrentWeather(city));
  } catch (err) {
    next(err);
  }
};

exports.recommendation = async (req, res, next) => {
  try {
    const city = resolveCity(req);
    if (!city) return res.status(400).json({ message: 'Provide ?city= or set a default city' });

    const [weather, recentWorkouts] = await Promise.all([
      getCurrentWeather(city),
      Workout.find({ user: req.user._id }).sort({ date: -1 }).limit(5),
    ]);

    const recommendation = await getRecommendation({
      weather,
      recentWorkouts,
      workoutType: req.query.workoutType,
    });
    res.json({ weather, recommendation });
  } catch (err) {
    next(err);
  }
};
