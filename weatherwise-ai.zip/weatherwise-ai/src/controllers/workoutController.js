const Workout = require('../models/Workout');

// Only fields a client is allowed to set
const pick = (body) => {
  const allowed = ['type', 'durationMinutes', 'distanceKm', 'caloriesBurned', 'location', 'notes', 'date'];
  return Object.fromEntries(Object.entries(body).filter(([k]) => allowed.includes(k)));
};

exports.createWorkout = async (req, res, next) => {
  try {
    const workout = await Workout.create({ ...pick(req.body), user: req.user._id });
    res.status(201).json(workout);
  } catch (err) {
    next(err);
  }
};

exports.getWorkouts = async (req, res, next) => {
  try {
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const filter = { user: req.user._id };
    if (req.query.type) filter.type = String(req.query.type);

    const [items, total] = await Promise.all([
      Workout.find(filter).sort({ date: -1 }).skip((page - 1) * limit).limit(limit),
      Workout.countDocuments(filter),
    ]);
    res.json({ page, limit, total, items });
  } catch (err) {
    next(err);
  }
};

exports.getWorkout = async (req, res, next) => {
  try {
    const workout = await Workout.findOne({ _id: req.params.id, user: req.user._id });
    if (!workout) return res.status(404).json({ message: 'Workout not found' });
    res.json(workout);
  } catch (err) {
    next(err);
  }
};

exports.updateWorkout = async (req, res, next) => {
  try {
    const workout = await Workout.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      pick(req.body),
      { new: true, runValidators: true }
    );
    if (!workout) return res.status(404).json({ message: 'Workout not found' });
    res.json(workout);
  } catch (err) {
    next(err);
  }
};

exports.deleteWorkout = async (req, res, next) => {
  try {
    const workout = await Workout.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!workout) return res.status(404).json({ message: 'Workout not found' });
    res.json({ message: 'Workout deleted' });
  } catch (err) {
    next(err);
  }
};
