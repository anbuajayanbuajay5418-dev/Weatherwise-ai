# WeatherWise AI

A Node.js/Express backend that securely manages user authentication and workout records via REST APIs,
and uses real-time weather data plus Google Gemini to give personalized workout recommendations.

## Setup
```bash
npm install
cp .env.example .env   # fill in MONGO_URI, JWT_SECRET, OPENWEATHER_API_KEY, GEMINI_API_KEY
npm run dev
```
Requires Node 18+ and a running MongoDB.

## API
All routes except register/login need `Authorization: Bearer <token>`.

| Method | Endpoint | Description |
|---|---|---|
| POST | /api/auth/register | Create account `{name,email,password,city?}` |
| POST | /api/auth/login | Login `{email,password}` -> JWT |
| GET | /api/auth/me | Current user |
| POST | /api/workouts | Create workout |
| GET | /api/workouts?page=&limit=&type= | List your workouts |
| GET | /api/workouts/:id | Get one |
| PUT | /api/workouts/:id | Update |
| DELETE | /api/workouts/:id | Delete |
| GET | /api/weather/current?city= | Real-time weather |
| GET | /api/weather/recommendation?city=&workoutType= | AI recommendation |

### Example
```bash
curl -X POST localhost:5000/api/auth/register -H "Content-Type: application/json" \
  -d '{"name":"Asha","email":"asha@example.com","password":"secret123","city":"Coimbatore"}'

curl -X POST localhost:5000/api/workouts -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"type":"running","durationMinutes":30,"distanceKm":5}'

curl "localhost:5000/api/weather/recommendation?workoutType=running" -H "Authorization: Bearer $TOKEN"
```

## Structure
```
server.js
src/
  app.js            Express setup, security middleware, routes
  config/db.js      MongoDB connection
  models/           User, Workout
  middleware/       auth (JWT), error handling
  controllers/      auth, workouts, weather
  routes/           route definitions
  services/         weatherService (OpenWeatherMap), aiService (Gemini)
```
